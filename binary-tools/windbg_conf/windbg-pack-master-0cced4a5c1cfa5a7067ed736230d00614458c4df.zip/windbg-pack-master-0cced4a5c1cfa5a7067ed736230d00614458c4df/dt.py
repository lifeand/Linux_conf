import argparse
import pykd
import sys

from copy import deepcopy

#scriptName = sys.argv[0] 
scriptName = 'dt.py'

def getTypeByName(typeName):
    try:
        return pykd.typeInfo(typeName)
    except pykd.SymbolException:
        pykd.dprintln("failed to find type information for '%s'" % typeName)
        quit()
    
def removeOpenKey(openkeys, key):

    s = ""
    for openkey in openkeys:  
        splitkey = key.split('.')
        splitopenkey = openkey.split('.')   
        
        if len(splitkey)<=len(splitopenkey) and splitkey == splitopenkey[:len(splitkey)]:
            newkey = ".".join(splitkey[:-1])
            s = s + '|' + newkey if s else newkey
        else:
            s = s + '|' + openkey if s else openkey
                
    return s
    
def addOpenKey(openkeys, key):

    s = ""
    for openkey in openkeys:  
        splitkey = key.split('.')
        splitopenkey = openkey.split('.')    
        if len(splitkey)>=len(splitopenkey) and splitkey[:len(splitopenkey)] == splitopenkey:
            continue
        else:
            s = s + '|' + openkey if s else openkey
                
    s = s + '|' + key if s else key 
                
    return s
       
   
def isKeyOpened(openkeys, key):
    
    for openkey in openkeys:        
        splitkey = key.split('.')
        splitopenkey = openkey.split('.')
        if len(splitkey)<=len(splitopenkey) and splitkey == splitopenkey[:len(splitkey)]:
            return True
    return False

def canBeOpened(value):

    try:
   
        if value.type().isUserDefined():
            return True
            
        if value.type().isPointer() and value.type().deref().isUserDefined():
            value.deref()
            return True
            
        if value.type().isArray():
            return True
      
    except pykd.MemoryException:
        pass        
        
    return False

    
class TypedVarPrinter(object):

    def __init__(self, args):
        self.showHex = args.intAsHex
        self.typeName = args.type_name
        self.address = pykd.expr(args.address)
        self.openkeys = args.openkeys.split('|')
        
    def printOut(self):

        typeObj = getTypeByName(self.typeName)
        var = pykd.typedVar(typeObj, self.address)
    
        if var.type().isUserDefined():
            return self.printStruct(var)
       
        pykd.dprintln( str(var) )
        
    def printStruct(self, var):
    
        pykd.dprintln('Type: {0},  Address: {1:#x},  Size: {2:d}({2:#x}) bytes'.format(self.typeName, self.address, var.type().size()) )
        
        if self.showHex:
            globalCommands = "<link cmd=\"!py {0} {1} {2:#x} --openkeys={3}\">Hex:On</link>".format(scriptName, self.typeName, self.address, "|".join(self.openkeys))
        else:
            globalCommands = "<link cmd=\"!py {0} {1} {2:#x} --openkeys={3} --intAsHex\">Hex:Off</link>".format(scriptName, self.typeName, self.address, "|".join(self.openkeys))
        
        pykd.dprintln( globalCommands, dml=True )   
 
        pykd.dprintln('+/-   {0:<10}{1:<23}{2}'.format('Offset:', 'Field:', 'Value:') )
        pykd.dprintln('-'*80)
    
        self.printStructField(var, "", 0)
        
    def printStructField(self, var, rootkey, level):

        for name, offset, value in var.fields():
   
            strValue = '%s  %s' % (value.type().name(), self.printShortValue(value))
       
            valueCmd = self.printCommands(value)
            prefix = "" if level==0 else " |" *level

            key =  name if rootkey == "" else rootkey + "." + name
            keyopened = isKeyOpened(self.openkeys, key)
            canOpen = canBeOpened(value)
   
            if keyopened:  
                newopenkey = removeOpenKey(self.openkeys, key)
                detail = "<link cmd=\"!py {0} {1} {2:#x} --openkeys={3}\">{4}</link>".format(scriptName, self.typeName, self.address, newopenkey, '-')
            elif canOpen:
                newopenkey = addOpenKey(self.openkeys, key)
                detail = "<link cmd=\"!py {0} {1} {2:#x} --openkeys={3}\">{4}</link>".format(scriptName, self.typeName, self.address, newopenkey, '+')
            else:
                detail = " "
            
            pykd.dprintln('{0}{1}     {2:>04x}      {3:<20} : {4}    {5}'.format(prefix, detail, offset, name, strValue, valueCmd), dml=True)
        
            if keyopened:
            
                try:
                
                    if value.type().isPointer() and value.type().deref().isUserDefined():
                        value = value.deref()
        
                    if value.type().isUserDefined(): 
                        self.printStructField(value, key, level+1)
                        
                    if value.type().isArray():
                        self.printArrayField(value, key, level+1)
            
                except pykd.MemoryException:
                    pass

    def printArrayField(self, var, rootkey, level):
   
        for i in xrange( min( len(var), 20 ) ):
        
            value = var[i]
        
            strValue = '%s  %s' % (value.type().name(), self.printShortValue(value))
       
            valueCmd = self.printCommands(value)
            prefix = "" if level==0 else " |" *level

            offset = i * value.sizeof()
        
            detail = " "
        
            name = '[{0}]'.format(i)
        
            pykd.dprintln('{0}{1}     {2:>04x}      {3:<20} : {4}    {5}'.format(prefix, detail, offset, name, strValue, valueCmd), dml=True)


    def printCommandsBase(self,var):
        #return "<link cmd=\"changeHex\">HEX|bin|unsigned|signed</link>"
        return ""

    def printValueBase(self,var):    
        try:
  
            return  hex(var) if self.showHex else str(long(var))  
        except pykd.MemoryException:    
            return "Invalid address"
        
    def printValuePtr(self,var):
        try:
            return '{0:x}'.format(long(var))
        except pykd.MemoryException:
            return "Invalid address" 

    def printCommnadsPtr(self,var):
        if var.type().deref().isUserDefined():
            return "<link cmd=\"!py {0} {1} {2:#x}\">-></link>".format(scriptName, var.type().deref().name(), var.getAddress())
        return  "<link cmd=\"db {0:#x} L200\">db</link>".format(var.getAddress())

    def printValueStruct(self,var):
        return "struct"
    
    def printShortValue(self,var):
        if var.type().isBase():
            return self.printValueBase(var)   
        if var.type().isPointer():
            return self.printValuePtr(var)
        if var.type().isUserDefined():
            return self.printValueStruct(var)
        return ""
    
    def printCommands(self,var):
        if var.type().isBase():
            return self.printCommandsBase(var)      
        if var.type().isPointer():
            return self.printCommnadsPtr(var)
        return ''                
    

def main():
    parser = argparse.ArgumentParser(description='Display typed varibale')
    parser.add_argument('type_name', type=str, help='type name')        
    parser.add_argument('address', type=str, help='address of variable')
    parser.add_argument('--openkeys', help='open keys in tree view', default="")
    parser.add_argument('--intAsHex', action='store_true', help='show int as hex')
    args = parser.parse_args()
    
    TypedVarPrinter(args).printOut()
    
if __name__ == "__main__":
    main()