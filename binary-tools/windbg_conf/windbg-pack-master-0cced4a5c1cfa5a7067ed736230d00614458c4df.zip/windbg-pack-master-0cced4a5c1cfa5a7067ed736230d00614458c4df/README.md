#  WinDBG scripts pack

This is a set of windbg script for common use in the windbg

## How to install

0. You should have installed windbg, pykd boostrapper and pykd package ( [How to](https://githomelab.ru/pykd/pykd/wikis/Pykd%20bootstrapper) )
1. [Download](/../repository/master/archive.zip) last archive and unpack it

## How to run
1. Start windbg
2. Start debug session
3. Load pykd ( .load pykd )

It is convinient to use additional window 'command browser'. You can open it the with 'Ctrl+N' shortcut

## List of script
 
 * help.py - interactive help for pykd
 * dt.py -dml version of the 'dt' command
 
Example:
```
>!py dt.py _PEB $peb
```
